<?php

/**
 * sfMediaFile filter form.
 *
 * @package    sfMediaPlugin
 * @subpackage filter
 * @author     Moujahid Mohamed
 * @version    SVN: $Id: sfDoctrineFormFilterTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
abstract class PluginsfMediaFileFormFilter extends BasesfMediaFileFormFilter
{
  public function configure()
  {
  }
}
