<?php

class Factory
{

  public static function getVideoInfo($url, $code_v){
    $type = "";
    $id = -1;
    $titre = "no title";
    $description = "no description";
    $code = "no code";
    $img = "no image";
    //Détermination du "type" de vidéo :
    if(eregi("youtube",$url))            $type="youtube";
    else if(eregi("dailymotion",$url))    $type="dailymotion";
    else if(eregi("google",$url))        $type="google";
    else if(eregi("vimeo",$url))        $type="vimeo";
    else if(eregi("youtu",$url))        $type="youtube";
    else return false;

    //Détermination de l'"ID" de la vidéo :
    if($type=="youtube"){
      $url = str_replace("?fs=1", "",$url);
      $debut_id = explode("/v/",$url,2);

          if (count($debut_id) == 1) {
            $debut_id = explode("?v=", $url, 2);
            $id = $debut_id[1];
          } else {
            $id_et_fin_url = explode("&",$debut_id[1],2);
            $id = $id_et_fin_url[0];
          }
      }
      else if($type=="dailymotion"){
          $debut_id = explode("/video/",$url,2);

          $id_et_fin_url = explode("_",$debut_id[1],2);
          $id = $id_et_fin_url[0];
          if(strstr($id, "?")) {
            $pos = stripos($id, "?");
            $id = substr($id, 0, $pos);
          }
      }
      else if($type=="google"){
          $debut_id =  explode("docid=",$url,2);
          $id_et_fin_url = explode("&",$debut_id[1],2);
          $id = $id_et_fin_url[0];
      }
      else if($type=="vimeo"){
          $l_id= eregi("([0-9]+)$",$url,$lid);
          $id = $lid[0];
      }

      $title = "";

      //Analyse et stockage des informations de la vidéo
      if($type=="youtube"){
      //Image
          $img = "http://img.youtube.com/vi/".$code_v."/0.jpg";
          //Code HTML
          $code = 'http://www.youtube.com/v/'.$code_v;

          $url = "http://gdata.youtube.com/feeds/api/videos/". $code_v;
        $doc = new DOMDocument;
        $doc->load($url);
        $title = $doc->getElementsByTagName("title")->item(0)->nodeValue;
      }
      else if ($type=="dailymotion"){
          $img = "http://www.dailymotion.com/thumbnail/200x200/video/".$id;
          // code HTML
          $code = 'http://www.dailymotion.com/swf/'.$id;

      $url = "http://www.dailymotion.com/rss/video/". $id;
      $doc = new DOMDocument;
      $doc->load($url);
      $title = str_replace("Dailymotion -", "", $doc->getElementsByTagName("title")->item(0)->nodeValue);
      }
      else if ($type=="google"){

          //image
          $xml_image_debut = explode('&lt;img src="',$xml_string,2);
          $xml_image_fin = explode('" width="',$xml_image_debut[1],2);
          $img = $xml_image_fin[0];
          //code HTML
          $code = 'http://video.google.com/googleplayer.swf?docId='.$id.'&hl=fr';
      }
      else if ($type=="vimeo"){
          //image
          $xml_image_debut = explode("<thumbnail_large>",$xml_string,2);
          $xml_image_fin = explode("</thumbnail_large>",$xml_image_debut[1],2);
          $img = $xml_image_fin[0];
          //code HTML
          $code = "http://vimeo.com/api/oembed.xml?url=http%3A//vimeo.com/".$id;
      }
      $id = str_replace(array("?fs=1", "="), "", $id);
      return array( "id"=>$id, "type"=>$type, "img"=>$img, "code"=>$code, 'title' => $title);
  }


}


 ?>