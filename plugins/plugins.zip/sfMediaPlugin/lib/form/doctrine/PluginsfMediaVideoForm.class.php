<?php

/**
 * sfMediaVideo form.
 *
 * @package    sfMediaPlugin
 * @subpackage form
 * @author     Moujahid Mohamed
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
abstract class PluginsfMediaVideoForm extends BasesfMediaVideoForm
{
  /**
   * @see sfMediaFileForm
   */
  public function configure()
  {
    parent::configure();
  }
}
